package headfirst.factory.pizzaaf;

public class Garlic implements Veggies {

	public String toString() {
		return "Garlic";
	}
}
